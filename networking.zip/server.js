import { Server } from "socket.io";

const io = new Server(8080, {
  cors: {
    origin: "https://mounderfod.github.io/en-passant/",
  },
});

io.on("connect_error", (err) => {
  console.log(`connect_error due to ${err.message}`);
});

io.on("connection", (s) => {
  console.log(`Connected with id ${s.id}`);

  s.emit("connected");

  s.on("join", (code, callback) => {
    if (
      io.sockets.adapter.rooms.get(code) &&
      io.sockets.adapter.rooms.get(code).size == 2
    ) {
      callback({
        status: "failed",
      });
    } else {
      console.log(`Adding ${s.id} to ${code}...`);
      s.join(code);
      io.to(code).emit("joined", { id: s.id, room: code });

      callback({
        status: "ok",
      });

      let room;
      io.in(code)
        .fetchSockets()
        .then((x) => {
          if (x.length == 2) {
            console.log(`Game ${code} is ready to begin! Initialising...`);
            let start = Math.floor(Math.random() * 2);
            let players =
              start == 2
                ? {
                    w: x[0].id,
                    b: x[1].id,
                  }
                : {
                    w: x[1].id,
                    b: x[0].id,
                  };

            io.to(code).emit("started", {
              players: players,
            });
          }
        });
    }
  });

  s.on("move", (...args) => {
    console.log(`Move received for game ${args[0].code}: ${args[0].move}`);
    s.to(args[0].code).emit("moved", args[0]);
  });

  s.on("gameOver", (...args) => {
    io.to(args[0].code).emit("gameOvered", args[0]);
    s.in(args[0].code).disconnectSockets();
  });
});
